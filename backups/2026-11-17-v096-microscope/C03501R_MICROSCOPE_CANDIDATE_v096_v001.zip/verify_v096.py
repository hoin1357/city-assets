import bpy,bmesh,math,json,pathlib
P=pathlib.Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(P/'C03501R_MICROSCOPE_ASSET_v001.blend'));R=list(bpy.data.collections['RENDER_C03501R'].objects);C=list(bpy.data.collections['COLLISION_PROXY'].objects)
report={'method':'Fresh Blender process; independent topology, dimensions, component counts, aperture and GLB triangle checks; no build imports','unity':'NOT_RUN','city_placement':'NOT_RUN','optical_medical_function':'NOT_IMPLEMENTED_NOT_VALIDATED','errors':[]};ps=[];tri=0
for o in R+C:
 bm=bmesh.new();bm.from_mesh(o.data)
 if any(not e.is_manifold for e in bm.edges):report['errors'].append(o.name+':non_manifold')
 if any(f.calc_area()<=1e-12 for f in bm.faces):report['errors'].append(o.name+':degenerate')
 if bm.calc_volume(signed=True)<=0:report['errors'].append(o.name+':non_positive_volume')
 assert all(math.isfinite(x) for v in bm.verts for x in v.co)
 if o in C:assert len(bm.verts)==8 and len(bm.faces)==6
 if o in R:ps.extend([o.matrix_world@v.co for v in o.data.vertices]);tri+=sum(len(f.verts)-2 for f in bm.faces)
 bm.free()
lo=[min(p[i] for p in ps) for i in range(3)];hi=[max(p[i] for p in ps) for i in range(3)];dims=[hi[i]-lo[i] for i in range(3)];assert abs(lo[2])<1e-6 and .44<hi[2]<.49
ocular=[o for o in R if o.name.startswith('Ocular') and o.name.endswith('_eyecup')];objectives=[o for o in R if o.name.startswith('Objective') and o.name.endswith('_barrel')];assert len(ocular)==2 and len(objectives)==3 and len(C)==7
assert not [i for i in bpy.data.images if i.source=='FILE' and not i.packed_file]
def bounds(name):
 o=bpy.data.objects[name];v=[o.matrix_world@p.co for p in o.data.vertices];return ([min(p[i] for p in v) for i in range(3)],[max(p[i] for p in v) for i in range(3)])
left,right,front,back=[bounds(n) for n in ['Stage_left','Stage_right','Stage_front','Stage_back']];hole=[right[0][0]-left[1][0],back[0][1]-front[1][1]];assert all(.035<h<.037 for h in hole)
clearance=bounds('Objective0_lens')[0][2]-bounds('Specimen_slide')[1][2];assert clearance>.02
report['native']={'render_meshes':len(R),'collision_boxes':len(C),'triangles':tri,'bbox_min':lo,'bbox_max':hi,'dimensions':dims,'oculars':len(ocular),'objective_barrels':len(objectives),'stage_aperture_xy':hole,'objective_to_slide_gap':clearance,'external_dependencies':False};report['glb']={}
for kind,count in [('RENDER',len(R)),('COL',len(C))]:
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(P/f'C03501R_MICROSCOPE_{kind}_v001.glb'));meshes=[o for o in bpy.data.objects if o.type=='MESH'];assert len(meshes)==count
 for o in meshes:
  o.data.calc_loop_triangles();assert all(t.area>1e-12 for t in o.data.loop_triangles),o.name
 v=[o.matrix_world@p.co for o in meshes for p in o.data.vertices];d=[max(p[i] for p in v)-min(p[i] for p in v) for i in range(3)]
 if kind=='RENDER':assert max(abs(d[i]-dims[i]) for i in range(3))<1e-5
 report['glb'][kind]={'meshes':len(meshes),'dimensions':d,'reimport':'PASS','triangle_areas':'PASS'}
report['status']='PASS' if not report['errors'] else 'FAIL';(P/'INDEPENDENT_QA.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert report['status']=='PASS'
