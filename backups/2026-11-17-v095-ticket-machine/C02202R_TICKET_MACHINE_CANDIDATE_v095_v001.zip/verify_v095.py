import bpy,bmesh,math,json,pathlib
P=pathlib.Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(P/'C02202R_TICKET_MACHINE_ASSET_v001.blend'));R=list(bpy.data.collections['RENDER_C02202R'].objects);C=list(bpy.data.collections['COLLISION_PROXY'].objects)
report={'method':'Fresh Blender process, independent topology, semantic parts and GLB reimport; no build imports','unity':'NOT_RUN','city_placement':'NOT_RUN','functionality':'NOT_IMPLEMENTED_NOT_VALIDATED','errors':[]};pts=[];tri=0
for o in R+C:
 bm=bmesh.new();bm.from_mesh(o.data)
 if any(not e.is_manifold for e in bm.edges):report['errors'].append(o.name+':non_manifold')
 if any(f.calc_area()<=1e-12 for f in bm.faces):report['errors'].append(o.name+':degenerate')
 if bm.calc_volume(signed=True)<=0:report['errors'].append(o.name+':volume')
 assert all(math.isfinite(x) for v in bm.verts for x in v.co)
 if o in C:assert len(bm.verts)==8 and len(bm.faces)==6
 if o in R:pts.extend([o.matrix_world@v.co for v in o.data.vertices]);tri+=sum(len(f.verts)-2 for f in bm.faces)
 bm.free()
lo=[min(v[i] for v in pts) for i in range(3)];hi=[max(v[i] for v in pts) for i in range(3)];dims=[hi[i]-lo[i] for i in range(3)];assert abs(lo[2])<1e-5 and 1.56<hi[2]<1.58
for name in ['Reel0_paper','Reel1_paper','Crank_arm','Crank_grip','Issued_ticket','Inspection_glass','Vertical_ticket_feed']:assert name in bpy.data.objects
assert len(C)==7;assert not [i for i in bpy.data.images if i.source=='FILE' and not i.packed_file]
window=bpy.data.objects['Inspection_glass'];assert .22<window.dimensions.x<.24 and .34<window.dimensions.z<.36
assert bpy.data.objects['Reel0_paper'].location.z>bpy.data.objects['Reel1_paper'].location.z
assert bpy.data.objects['Crank_grip'].location.x>.30
report['native']={'render_meshes':len(R),'collision_boxes':len(C),'triangles':tri,'bbox_min':lo,'bbox_max':hi,'dimensions':dims,'paper_reels':2,'crank':'static right-hand crank','inspection_window':list(window.dimensions),'external_dependencies':False};report['glb']={}
for kind,count in [('RENDER',len(R)),('COL',len(C))]:
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(P/f'C02202R_TICKET_MACHINE_{kind}_v001.glb'));meshes=[o for o in bpy.data.objects if o.type=='MESH'];assert len(meshes)==count
 for o in meshes:
  o.data.calc_loop_triangles();assert all(t.area>1e-12 for t in o.data.loop_triangles),o.name
 ps=[o.matrix_world@v.co for o in meshes for v in o.data.vertices];d=[max(v[i] for v in ps)-min(v[i] for v in ps) for i in range(3)]
 if kind=='RENDER':assert max(abs(d[i]-dims[i]) for i in range(3))<1e-5
 report['glb'][kind]={'meshes':len(meshes),'dimensions':d,'reimport':'PASS','triangle_area':'PASS'}
report['status']='PASS' if not report['errors'] else 'FAIL';(P/'INDEPENDENT_QA.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert report['status']=='PASS'
