import bpy,json
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
O=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(O/'C03407R_IV_STAND_ASSET_v001.blend'));s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=32;s.cycles.use_denoising=False
for vl in s.view_layers:vl.cycles.use_denoising=False
s.render.resolution_x=800;s.render.resolution_y=1100;s.render.resolution_percentage=100;s.world=bpy.data.worlds.new('PREVIEW_WORLD');s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.14,.18,.21,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.5
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.002));floor=bpy.context.object;floor.name='PREVIEW_FLOOR';m=bpy.data.materials.new('PREVIEW_FLOOR');m.diffuse_color=(.1,.13,.16,1);floor.data.materials.append(m)
for loc,energy,size in [((-2,-3,4),450,3),((3,1,3),700,2)]:
 d=bpy.data.lights.new('PREVIEW_LIGHT','AREA');d.energy=energy;d.size=size;l=bpy.data.objects.new(d.name,d);s.collection.objects.link(l);l.location=loc;l.rotation_euler=(Vector((0,0,1))-l.location).to_track_quat('-Z','Y').to_euler()
d=bpy.data.cameras.new('PREVIEW_CAMERA');cam=bpy.data.objects.new(d.name,d);s.collection.objects.link(cam);s.camera=cam;d.type='ORTHO';checks=[]
v=[];f=[];names=[]
for o in s.objects:
 if o.type!='MESH'or o.hide_render:continue
 n=len(v);v.extend(o.matrix_world@p.co for p in o.data.vertices)
 for p in o.data.polygons:f.append([n+i for i in p.vertices]);names.append(o.name)
T=BVHTree.FromPolygons(v,f)
for name,pos,target,scale,probe in [('PREVIEW_IV_STAND_HERO_v091.png',(2.7,-4,2.5),(0,0,1),2.3,(0,0,1)),('PREVIEW_IV_STAND_HOOKS_v091.png',(.8,-1.2,2.6),(0,0,1.93),.61,(0,0,1.925))]:
 cam.location=pos;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=scale;dr=Vector(probe)-cam.location;p,n,i,dist=T.ray_cast(cam.location,dr.normalized(),dr.length+.3);hit=names[i]if i is not None else None;assert hit and hit.startswith('C03407R_');checks.append({'image':name,'first_hit':hit});s.render.filepath=str(O/name);bpy.ops.render.render(write_still=True)
(O/'CAMERA_VISIBILITY.json').write_text(json.dumps(checks,indent=2));print('PREVIEW_NO_SAVE')
