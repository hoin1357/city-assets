import bpy,json,hashlib,numpy as np
from pathlib import Path
from collections import Counter
from mathutils.kdtree import KDTree
from itertools import permutations
D=Path(__file__).resolve().parent;O=D.parent;asset=O/'C03407R_IV_STAND_ASSET_v001.blend';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before=sha(asset)
bpy.ops.wm.open_mainfile(filepath=str(asset));objs=[o for o in bpy.context.scene.objects if o.type=='MESH'];assert len(objs)==74
rows=[];expected={}
def surface(o):
 o.data.calc_loop_triangles();v=np.array([list(o.matrix_world@v.co)for v in o.data.vertices]);tris=v[[list(t.vertices)for t in o.data.loop_triangles]]
 return dict(raw_triangles=tris,triangles=len(tris),lo=v.min(0).tolist(),hi=v.max(0).tolist(),surface=sorted(tuple(sorted(tuple(round(float(k),5)for k in p)for p in t))for t in tris),COL=bool(o.get('is_collision_geometry')))
for o in objs:
 v=np.array([list(v.co)for v in o.data.vertices]);fs=[list(f.vertices)for f in o.data.polygons];edge=Counter();direction=Counter();assert len({tuple(sorted(f))for f in fs})==len(fs)
 for f in fs:
  for a,b in zip(f,f[1:]+f[:1]):edge[tuple(sorted((a,b)))]+=1;direction[(a,b)]+=1
 assert all(n==2 for n in edge.values())and all(direction[(b,a)]==1 for a,b in direction)
 o.data.calc_loop_triangles();T=v[[list(t.vertices)for t in o.data.loop_triangles]];norm=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]);area=np.linalg.norm(norm,axis=1)/2;assert area.min()>1e-10
 vol=float(np.einsum('ij,ij->i',T[:,0],np.cross(T[:,1],T[:,2])).sum()/6);assert vol>0
 col=bool(o.get('is_collision_geometry'))
 if col:
  for t,n in zip(T,norm):assert np.max((v-t[0])@(n/np.linalg.norm(n)))<1e-5,o.name
 else:
  assert o.data.uv_layers
  uv=np.array([list(p.uv)for p in o.data.uv_layers.active.data]);assert np.isfinite(uv).all()and uv.min()>-1e-5 and uv.max()<1.00001
 rows.append(dict(name=o.name,COL=col,vertices=len(v),triangles=len(T),Euler=len(v)-len(edge)+len(fs),min_area=float(area.min()),volume=vol,closed_oriented_edges=True,convex_checked=col,UV_checked=not col));expected[o.name]=surface(o)
assert sum(r['COL']for r in rows)==53
alllo=np.min([x['lo']for x in expected.values()],0);allhi=np.max([x['hi']for x in expected.values()],0);assert abs(alllo[2])<1e-6 and 2.0<allhi[2]<2.02
from mathutils.bvhtree import BVHTree
from mathutils import Vector
planes=[];render_samples=[]
for o in objs:
 vv=np.array([list(o.matrix_world@p.co)for p in o.data.vertices]);o.data.calc_loop_triangles();tt=vv[[list(t.vertices)for t in o.data.loop_triangles]]
 if o.get('is_collision_geometry'):
  nn=np.array([list(p.normal)for p in o.data.polygons]);pp=np.array([vv[p.vertices[0]]for p in o.data.polygons]);planes.append((nn,np.einsum('ij,ij->i',nn,pp),vv.min(0),vv.max(0)))
 else:render_samples.extend(vv);render_samples.extend(tt.mean(1));render_samples.extend((tt[:,0]+tt[:,1])/2);render_samples.extend((tt[:,1]+tt[:,2])/2);render_samples.extend((tt[:,2]+tt[:,0])/2)
def cover(points):
 m=np.zeros(len(points),bool)
 for nn,off,lo,hi in planes:
  ids=np.flatnonzero(~m & np.all(points>=lo-1e-6,1)&np.all(points<=hi+1e-6,1))
  if len(ids):m[ids]=np.all(points[ids]@nn.T<=off+1e-6,1)
 return m
pts=np.array(render_samples);assert cover(pts).all(),pts[~cover(pts)].tolist()[:10]
# The upper mouths admit a narrow diagnostic probe, not a medical hanging/load certification.
hooks=[]
for k in range(4):
 angle=k*np.pi/2;rad=np.array([np.cos(angle),np.sin(angle),0]);tang=np.array([-np.sin(angle),np.cos(angle),0]);pts=np.array([rad*r+tang*t+[0,0,z]for r in np.linspace(.16,.20,9)for t in np.linspace(-.009,.009,5)for z in np.linspace(1.96,2.04,17)])
 assert not cover(pts).any(),('hook mouth COL filled',k)
 hooks.append({'hook':k,'COL_mouth_empty_points':len(pts),'radial_range':[.16,.20],'height_range':[1.96,2.04],'tangential_range':[-.009,.009]})
rays=[]
for role,sub in [('render',[o for o in objs if not o.get('is_collision_geometry')]),('COL',[o for o in objs if o.get('is_collision_geometry')])]:
 vs=[];fs=[]
 for o in sub:
  off=len(vs);vs.extend(o.matrix_world@v.co for v in o.data.vertices);fs.extend([off+i for i in p.vertices]for p in o.data.polygons)
 BV=BVHTree.FromPolygons(vs,fs)
 for k in range(4):
  t=k*np.pi/2;start=Vector((.18*np.cos(t),.18*np.sin(t),2.04));hit=BV.ray_cast(start,Vector((0,0,-1)),.08);assert hit[0]is None,(role,k);rays.append({'role':role,'hook':k,'mouth_down_ray_clear':True})
feet=[];centers=[]
for k in range(5):
 ob=bpy.data.objects[f'C03407R_FOOT_{k}'];vv=np.array([list(ob.matrix_world@p.co)for p in ob.data.vertices]);bottom=vv[np.abs(vv[:,2])<1e-7];assert len(bottom)==16 and abs(vv[:,2].min())<1e-7 and abs(vv[:,2].max()-.035)<1e-6;center=bottom[:,:2].mean(0);centers.append(center);assert abs(np.linalg.norm(center)-.27)<1e-6;feet.append({'foot':k,'bottom_vertices_z0':len(bottom),'center_xy':center.tolist(),'height_m':float(vv[:,2].max())})
for a,b in zip(centers,centers[1:]+centers[:1]):assert np.cross(b-a,-a)>0
coverage={'all_render_sampled_surface_points_inside_COL':len(render_samples),'hook_mouth_samples':hooks,'mouth_rays':rays,'five_foot_contacts':feet,'mast_axis_inside_five_contact_centers_polygon':True,'not_physical_stability_or_clinical_safety_rating':True}
exports=[]
for label,count,col in [('RENDER',21,False),('COL',53,True)]:
 p=O/f'C03407R_IV_STAND_{label}_v001.glb';h=sha(p);bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(p));loaded=[o for o in bpy.context.scene.objects if o.type=='MESH'];assert len(loaded)==count
 for o in loaded:
  assert o.name in expected;got=surface(o);ref=expected[o.name];assert got['triangles']==ref['triangles']and got['COL']==col and ref['COL']==col
  assert np.allclose(got['lo'],ref['lo'],atol=1e-5)and np.allclose(got['hi'],ref['hi'],atol=1e-5)
  tree=KDTree(len(ref['raw_triangles']))
  for ix,t in enumerate(ref['raw_triangles']):tree.insert(t.mean(0),ix)
  tree.balance();used=set();maxerr=0
  for t in got['raw_triangles']:
   found=None
   for _,ix,_ in tree.find_range(t.mean(0),1e-5):
    if ix in used:continue
    err=min(float(np.max(np.linalg.norm(t-ref['raw_triangles'][ix][list(order)],axis=1)))for order in permutations(range(3)))
    if err<1e-5:found=ix;maxerr=max(maxerr,err);break
   assert found is not None,(o.name,'unmatched triangle');used.add(found)
  assert len(used)==got['triangles']
 assert sha(p)==h;exports.append(dict(label=label,meshes=count,triangles_world_surface_multiset_match=True,roles_match=True,sha256=h))
assert sha(asset)==before
(D/'INDEPENDENT_ASSET_v091.json').write_text(json.dumps(dict(status='PASS',asset_sha256=before,mesh_count=74,render_count=21,COL_count=53,dimensions=(allhi-alllo).tolist(),topology=rows,coverage=coverage,exports=exports,files_unchanged=True,limits=['Closed oriented topology is not generic self-intersection proof','UV finite and per-mesh packed; not shared atlas or baked validation','53 separate convex pieces; static geometry only, no medical function/load/stability rating','Unity NOT_RUN']),indent=2));print('PASS_ASSET',len(rows))
