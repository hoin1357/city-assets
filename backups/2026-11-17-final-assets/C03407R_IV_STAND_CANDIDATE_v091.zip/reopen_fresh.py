import bpy,json,bmesh,hashlib,sys
from pathlib import Path
O=Path(__file__).resolve().parent;out=Path(sys.argv[sys.argv.index('--')+1]);N=O/'C03407R_IV_STAND_ASSET_v001.blend';bpy.ops.wm.open_mainfile(filepath=str(N));obs=[o for o in bpy.context.scene.objects if o.type=='MESH'];assert len(obs)==74;COL=[o for o in obs if o.get('is_collision_geometry')];assert len(COL)==53
for o in obs:
 bm=bmesh.new();bm.from_mesh(o.data);assert all(e.is_manifold for e in bm.edges);assert bm.calc_volume(signed=True)>0;bm.free()
 if o in COL:assert max((v.co-o.data.vertices[p.vertices[0]].co).dot(p.normal)for p in o.data.polygons for v in o.data.vertices)<1e-6
out.write_text(json.dumps({'status':'PASS','meshes':74,'render':21,'COL':53,'native_sha256':hashlib.sha256(N.read_bytes()).hexdigest(),'convex_closed_positive_volume':'PASS','Unity':'NOT_RUN'},indent=2));print('FRESH_NATIVE_PASS')
