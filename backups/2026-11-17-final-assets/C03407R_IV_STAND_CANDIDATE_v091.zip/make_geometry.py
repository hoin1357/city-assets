import numpy as np,json,math
from pathlib import Path
from scipy.spatial import ConvexHull
O=Path(__file__).resolve().parent;meshes=[];colliders=[]
def hull(name,vs):
 v=np.unique(np.array(vs),axis=0);h=ConvexHull(v);f=h.simplices.copy()
 for i,t in enumerate(f):
  a,b,c=v[t]
  if np.dot(np.cross(b-a,c-a),h.equations[i,:3])<0:f[i]=t[::-1]
 used=np.unique(f);mp={int(i):j for j,i in enumerate(used)};colliders.append({'name':'C03407R_COL_'+name,'v':v[used].tolist(),'f':[[mp[int(i)]for i in t]for t in f]})
def cylinder(name,a,b,r1,r2,mat,n=16):
 a=np.array(a);b=np.array(b);d=(b-a)/np.linalg.norm(b-a);u=np.cross(d,[0,0,1]if abs(d[2])<.9 else[0,1,0]);u/=np.linalg.norm(u);w=np.cross(d,u);v=[(p+r*(math.cos(2*math.pi*i/n)*u+math.sin(2*math.pi*i/n)*w)).tolist()for p,r in [(a,r1),(b,r2)]for i in range(n)];f=[list(reversed(range(n))),list(range(n,2*n))]+[[i,(i+1)%n,(i+1)%n+n,i+n]for i in range(n)];meshes.append({'name':'C03407R_'+name,'v':v,'f':f,'mat':mat});hull(name,v)
cylinder('BASE_HUB',(0,0,.065),(0,0,.17),.04,.028,'steel')
cylinder('LOWER_MAST',(0,0,.12),(0,0,1.14),.018,.018,'steel')
cylinder('UPPER_MAST',(0,0,1.10),(0,0,1.935),.0125,.0125,'steel')
cylinder('HEIGHT_COLLAR',(0,0,1.085),(0,0,1.145),.026,.026,'dark')
cylinder('LOCK_SCREW',(0,-.015,1.115),(0,-.045,1.115),.005,.005,'steel',12)
cylinder('LOCK_KNOB',(0,-.043,1.115),(0,-.060,1.115),.016,.016,'dark',16)
cylinder('HOOK_HUB',(0,0,1.905),(0,0,1.945),.024,.024,'steel')
for i in range(5):
 t=2*math.pi*i/5;d=np.array([math.cos(t),math.sin(t),0]);cylinder(f'BASE_ARM_{i}',d*.025+[0,0,.11],d*.27+[0,0,.032],.018,.013,'steel',12);cylinder(f'FOOT_{i}',d*.27+[0,0,0],d*.27+[0,0,.035],.023,.023,'rubber',16)
# Four U-turn hooks with open mouths. Continuous ring tube, circular elbow centerline.
for k in range(4):
 angle=k*math.pi/2;rad=np.array([math.cos(angle),math.sin(angle),0]);tang=np.array([-math.sin(angle),math.cos(angle),0]);z=np.array([0,0,1]);path=[(.012,1.925),(.11,1.925),(.17,1.925)]
 for a in np.linspace(-math.pi/2,0,7)[1:]:path.append((.17+.055*math.cos(a),1.98+.055*math.sin(a)))
 path.append((.225,2.005));centers=[rad*r+z*h for r,h in path];v=[];n=10
 for i,p in enumerate(centers):
  direction=(centers[min(i+1,len(centers)-1)]-centers[max(i-1,0)]);direction/=np.linalg.norm(direction);other=np.cross(direction,tang)
  v.extend((p+.0075*(math.cos(2*math.pi*j/n)*tang+math.sin(2*math.pi*j/n)*other)).tolist()for j in range(n))
 f=[list(reversed(range(n))),list(range((len(centers)-1)*n,len(centers)*n))]
 for i in range(len(centers)-1):
  f.extend([[i*n+j,i*n+(j+1)%n,(i+1)*n+(j+1)%n,(i+1)*n+j]for j in range(n)]);hull(f'HOOK_{k}_SEG_{i}',v[i*n:(i+2)*n])
 meshes.append({'name':f'C03407R_HOOK_{k}','v':v,'f':f,'mat':'steel'})
(O/'GEOMETRY.json').write_text(json.dumps({'render':meshes,'COL':colliders}));print('GEOMETRY',len(meshes),len(colliders))
