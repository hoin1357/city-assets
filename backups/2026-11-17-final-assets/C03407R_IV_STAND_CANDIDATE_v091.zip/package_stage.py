from pathlib import Path
import json,hashlib,zipfile,shutil
O=Path(__file__).resolve().parent;B=O.parent/'backup_v091';B.mkdir(exist_ok=True);files=sorted(p for p in O.rglob('*')if p.is_file()and '__pycache__'not in p.parts)
m={str(p.relative_to(O)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in files};(B/'MANIFEST.json').write_text(json.dumps(m,indent=2));z=B/'C03407R_IV_STAND_CANDIDATE_v091.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,6)as f:
 for p in files:f.write(p,p.relative_to(O))
 f.write(B/'MANIFEST.json','MANIFEST.json')
(B/'INDEX.json').write_text(json.dumps({'files':len(files),'zip_bytes':z.stat().st_size,'zip_sha256':hashlib.sha256(z.read_bytes()).hexdigest(),'new_reconstruction_candidate':True,'catalogue_completed_added':0},indent=2));print(z,z.stat().st_size);assert shutil.disk_usage(O).free>2.3*2**30
