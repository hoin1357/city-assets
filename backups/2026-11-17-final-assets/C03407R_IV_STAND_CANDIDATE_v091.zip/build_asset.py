import bpy,json,bmesh,hashlib,shutil
from pathlib import Path
O=Path(__file__).resolve().parent;assert shutil.disk_usage(O).free>2.3*2**30+30*2**20;bpy.ops.wm.read_factory_settings(use_empty=True);s=bpy.context.scene;s.unit_settings.system='METRIC';C=bpy.data.collections.new('C03407R_IV_STAND_CANDIDATE');s.collection.children.link(C);G=json.load(open(O/'GEOMETRY.json'));mats={}
for name,color,metal,rough in [('steel',(.45,.52,.55,1),.8,.26),('dark',(.045,.08,.09,1),.1,.5),('rubber',(.025,.03,.032,1),0,.8)]:
 m=bpy.data.materials.new('C03407R_'+name);m.diffuse_color=color;m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=color;p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough;mats[name]=m
obs=[];qa=[]
for role,items in G.items():
 for q in items:
  me=bpy.data.meshes.new(q['name']);me.from_pydata(q['v'],[],q['f']);me.update();ob=bpy.data.objects.new(q['name'],me);C.objects.link(ob);bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));assert all(e.is_manifold for e in bm.edges);vol=bm.calc_volume(signed=True);assert vol>0;bm.to_mesh(me);bm.free();col=role=='COL';ob['is_collision_geometry']=col;ob['new_reconstruction_candidate']=True;ob['catalogue_completion_added']=0
  if col:
   worst=max((v.co-me.vertices[p.vertices[0]].co).dot(p.normal)for p in me.polygons for v in me.vertices);assert worst<1e-6;ob.hide_render=True;ob.hide_set(True);ob.display_type='WIRE'
  else:
   me.materials.append(mats[q['mat']]);bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob;bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(island_margin=.02);bpy.ops.object.mode_set(mode='OBJECT')
  obs.append(ob);qa.append({'name':ob.name,'vertices':len(me.vertices),'faces':len(me.polygons),'volume':vol,'COL':col})
bpy.context.preferences.filepaths.save_version=0;p=O/'C03407R_IV_STAND_ASSET_v001.blend';assert not p.exists();bpy.ops.wm.save_as_mainfile(filepath=str(p),compress=True);ex=[]
for label,col in [('RENDER',False),('COL',True)]:
 bpy.ops.object.select_all(action='DESELECT');sub=[o for o in obs if bool(o.get('is_collision_geometry'))==col]
 for o in sub:o.hide_set(False);o.select_set(True)
 p=O/f'C03407R_IV_STAND_{label}_v001.glb';bpy.ops.export_scene.gltf(filepath=str(p),export_format='GLB',use_selection=True,export_apply=True,export_extras=True);ex.append({'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'objects':len(sub)})
(O/'ASSET_QA.json').write_text(json.dumps({'status':'PASS','render_meshes':len(G['render']),'COL_meshes':len(G['COL']),'topology':qa,'exports':ex,'Unity':'NOT_RUN','catalogue_completed_added':0,'medical_function':'NOT_SIMULATED'},indent=2));print('ASSET_SAVED',len(obs))
