import bpy,bmesh,json,math,pathlib
from mathutils import Vector
P=pathlib.Path('/workspace/v093_medical_screen');bpy.ops.wm.open_mainfile(filepath=str(P/'C03307R_MEDICAL_SCREEN_ASSET_v001.blend'))
R=list(bpy.data.collections['RENDER_C03307R'].objects);C=list(bpy.data.collections['COLLISION_PROXY'].objects)
report={'method':'Fresh Blender process, native mesh topology and separate GLB reimport; no build script imports','unity':'NOT_RUN','medical_function_or_safety':'NOT_IMPLEMENTED_NOT_VALIDATED','native':{},'glb':{}}
pts=[];bad=[];tri=0
for o in R+C:
 bm=bmesh.new();bm.from_mesh(o.data);bm.normal_update()
 if any(not e.is_manifold for e in bm.edges):bad.append(o.name)
 assert all(math.isfinite(v) for p in o.data.vertices for v in p.co)
 assert all(f.calc_area()>1e-12 for f in bm.faces)
 assert bm.calc_volume(signed=True)>0, o.name
 if o in C: assert len(bm.verts)==8 and len(bm.faces)==6
 if o in R:
  pts.extend([o.matrix_world@v.co for v in o.data.vertices]);tri+=sum(len(f.verts)-2 for f in bm.faces)
 bm.free()
assert not bad,bad
lo=[min(p[i] for p in pts) for i in range(3)];hi=[max(p[i] for p in pts) for i in range(3)]
assert abs(lo[2])<1e-5 and 1.8<hi[2]<1.9
assert len([o for o in R if '_pleated_curtain' in o.name])==3
assert len([o for o in R if '_wheel' in o.name and 'hub' not in o.name])==6
assert len(C)==6
report['native']={'render_meshes':len(R),'collision_meshes':len(C),'triangles':tri,'bbox_min':lo,'bbox_max':hi,'dimensions':[hi[i]-lo[i] for i in range(3)],'non_manifold_meshes':bad,'curtains':3,'wheels':6,'external_images':[i.filepath for i in bpy.data.images if i.source=='FILE' and not i.packed_file]}
assert not report['native']['external_images']
for kind,expected in [('RENDER',len(R)),('COL',len(C))]:
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(P/f'C03307R_MEDICAL_SCREEN_{kind}_v001.glb'))
 meshes=[o for o in bpy.data.objects if o.type=='MESH'];assert len(meshes)==expected
 points=[o.matrix_world@v.co for o in meshes for v in o.data.vertices];dims=[max(v[i] for v in points)-min(v[i] for v in points) for i in range(3)]
 if kind=='RENDER':assert max(abs(dims[i]-report['native']['dimensions'][i]) for i in range(3))<1e-5
 report['glb'][kind]={'meshes':len(meshes),'dimensions':dims,'import':'PASS'}
report['status']='PASS';(P/'INDEPENDENT_QA.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
