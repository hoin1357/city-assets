import bpy,bmesh,pathlib,json,math
P=pathlib.Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(P/'C03801R_BOOK_RETURN_ASSET_v001.blend'))
R=list(bpy.data.collections['RENDER_C03801R'].objects);C=list(bpy.data.collections['COLLISION_PROXY'].objects);report={'method':'Independent fresh Blender process; native topology and separate GLB reimport, no build imports','unity':'NOT_RUN','city_placement':'NOT_RUN','medical_function':'NOT_IMPLEMENTED_NOT_VALIDATED','errors':[]};pts=[];tri=0
for o in R+C:
 bm=bmesh.new();bm.from_mesh(o.data);bm.normal_update()
 if any(not e.is_manifold for e in bm.edges):report['errors'].append(o.name+':non_manifold')
 if any(f.calc_area()<1e-12 for f in bm.faces):report['errors'].append(o.name+':degenerate')
 if bm.calc_volume(signed=True)<=0:report['errors'].append(o.name+':non_positive_volume')
 assert all(math.isfinite(x) for v in bm.verts for x in v.co)
 if o in C:assert len(bm.verts)==8 and len(bm.faces)==6
 if o in R:pts.extend([o.matrix_world@v.co for v in o.data.vertices]);tri+=sum(len(f.verts)-2 for f in bm.faces)
 bm.free()
lo=[min(v[i] for v in pts) for i in range(3)];hi=[max(v[i] for v in pts) for i in range(3)];dims=[hi[i]-lo[i] for i in range(3)]
assert abs(lo[2])<1e-5 and 1.4<hi[2]<1.5
assert all(n in bpy.data.objects for n in ['Interior_sloping_chute','Bin_bottom','Service_door_open','Header_BOOK_RETURN'])
assert not [i for i in bpy.data.images if i.source=='FILE' and not i.packed_file]
# Direct slot measurement from mesh world bounds, independent of build constants.
def bounds(name):
 o=bpy.data.objects[name];vs=[o.matrix_world@v.co for v in o.data.vertices];return ([min(v[i] for v in vs) for i in range(3)],[max(v[i] for v in vs) for i in range(3)])
header=bounds('Header_sign_panel');lower=bounds('Return_slot_lower');ls=bounds('Slot_side_-0.38');rs=bounds('Slot_side_0.38')
slot_width=rs[0][0]-ls[1][0];slot_height=header[0][2]-lower[1][2];assert .69<slot_width<.71 and .17<slot_height<.18
report['native']={'render_meshes':len(R),'collision_boxes':len(C),'triangles':tri,'bbox_min':lo,'bbox_max':hi,'dimensions':dims,'slot_width':slot_width,'slot_height':slot_height,'open_door_degrees':round(math.degrees(bpy.data.objects['Service_door_open'].rotation_euler.z),3),'external_dependencies':False};report['glb']={}
for kind,count in [('RENDER',len(R)),('COL',len(C))]:
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(P/f'C03801R_BOOK_RETURN_{kind}_v001.glb'))
 meshes=[o for o in bpy.data.objects if o.type=='MESH'];assert len(meshes)==count
 for o in meshes:
  o.data.calc_loop_triangles()
  assert all(t.area>1e-12 for t in o.data.loop_triangles), o.name+':GLB degenerate triangles'
 v=[o.matrix_world@p.co for o in meshes for p in o.data.vertices];d=[max(p[i] for p in v)-min(p[i] for p in v) for i in range(3)]
 if kind=='RENDER':assert max(abs(d[i]-dims[i]) for i in range(3))<1e-5
 report['glb'][kind]={'meshes':len(meshes),'dimensions':d,'reimport':'PASS'}
report['status']='PASS' if not report['errors'] else 'FAIL';(P/'INDEPENDENT_QA.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert report['status']=='PASS'
