import bpy,bmesh,math,json,pathlib
from mathutils import Vector
P=pathlib.Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(P/'C02706R_PAPER_CUTTER_ASSET_v002.blend'));R=list(bpy.data.collections['RENDER_C02706R'].objects);C=list(bpy.data.collections['COLLISION_PROXY'].objects);report={'method':'Independent fresh Blender process, no build imports; topology, solid volume, semantic geometry, GLB import and triangles','unity':'NOT_RUN','city_placement':'NOT_RUN','cutting_function':'NOT_IMPLEMENTED_NOT_VALIDATED','errors':[]};points=[];tri=0
for o in R+C:
 bm=bmesh.new();bm.from_mesh(o.data)
 if any(not e.is_manifold for e in bm.edges):report['errors'].append(o.name+':non_manifold')
 if any(f.calc_area()<=1e-12 for f in bm.faces):report['errors'].append(o.name+':degenerate')
 if bm.calc_volume(signed=True)<=0:report['errors'].append(o.name+':volume')
 assert all(math.isfinite(x) for v in bm.verts for x in v.co)
 if o in C:assert len(bm.verts)==8 and len(bm.faces)==6
 if o in R:points.extend([o.matrix_world@v.co for v in o.data.vertices]);tri+=sum(len(f.verts)-2 for f in bm.faces)
 bm.free()
lo=[min(v[i] for v in points) for i in range(3)];hi=[max(v[i] for v in points) for i in range(3)];dims=[hi[i]-lo[i] for i in range(3)];assert abs(lo[2])<1e-6
for n in ['Grid_lines','Hinge_pin','Lever_spine','Blade_visual_strip','Handle_grip','Clamp_bar','Paper_stack']:assert n in bpy.data.objects
axis=bpy.data.objects['Lever_spine'].matrix_world.to_3x3()@Vector((0,0,1));angle=math.degrees(math.asin(axis.normalized().z));assert abs(angle-30)<.001
assert len(C)==6;assert not [i for i in bpy.data.images if i.source=='FILE' and not i.packed_file]
report['native']={'render_meshes':len(R),'collision_boxes':len(C),'triangles':tri,'bbox_min':lo,'bbox_max':hi,'dimensions':dims,'lever_angle_degrees':angle,'grid_edges':len(bpy.data.objects['Grid_lines'].data.edges),'external_dependencies':False};report['glb']={}
for kind,count in [('RENDER',len(R)),('COL',len(C))]:
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(P/f'C02706R_PAPER_CUTTER_{kind}_v002.glb'));meshes=[o for o in bpy.data.objects if o.type=='MESH'];assert len(meshes)==count
 for o in meshes:
  o.data.calc_loop_triangles();assert all(t.area>1e-12 for t in o.data.loop_triangles),o.name
 pts=[o.matrix_world@v.co for o in meshes for v in o.data.vertices];d=[max(v[i] for v in pts)-min(v[i] for v in pts) for i in range(3)]
 if kind=='RENDER':assert max(abs(d[i]-dims[i]) for i in range(3))<1e-5
 report['glb'][kind]={'meshes':len(meshes),'dimensions':d,'reimport':'PASS','triangle_areas':'PASS'}
report['status']='PASS' if not report['errors'] else 'FAIL';(P/'INDEPENDENT_QA_v002.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert report['status']=='PASS'
