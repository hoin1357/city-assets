import bpy,pathlib
P=pathlib.Path('/workspace/v097_paper_cutter');bpy.ops.wm.open_mainfile(filepath=str(P/'C02706R_PAPER_CUTTER_ASSET_v002.blend'))
o=bpy.data.objects['Lever_accent'];loc=o.location.copy();rot=o.rotation_euler.copy();mat=o.data.materials[0];bpy.data.objects.remove(o,do_unlink=True)
bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name='Lever_accent';o.dimensions=(.023,.004,.12);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.rotation_euler=rot
for c in list(o.users_collection):c.objects.unlink(o)
bpy.data.collections['RENDER_C02706R'].objects.link(o);o.data.materials.append(mat)
for kind,coll in [('RENDER','RENDER_C02706R'),('COL','COLLISION_PROXY')]:
 bpy.ops.object.select_all(action='DESELECT')
 for o in bpy.data.collections[coll].objects:o.hide_set(False);o.select_set(True)
 bpy.ops.export_scene.gltf(filepath=str(P/f'C02706R_PAPER_CUTTER_{kind}_v003.glb'),export_format='GLB',use_selection=True,export_apply=True)
for o in bpy.data.collections['COLLISION_PROXY'].objects:o.hide_set(True)
bpy.ops.object.select_all(action='DESELECT');bpy.context.scene.render.filepath=str(P/'PREVIEW_PAPER_CUTTER_HERO_v097_v003.png');bpy.ops.wm.save_as_mainfile(filepath=str(P/'C02706R_PAPER_CUTTER_ASSET_v003.blend'),compress=True)
