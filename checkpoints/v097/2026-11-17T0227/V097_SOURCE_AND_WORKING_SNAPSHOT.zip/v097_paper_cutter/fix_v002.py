import bpy,pathlib,bmesh
P=pathlib.Path('/workspace/v097_paper_cutter');bpy.ops.wm.open_mainfile(filepath=str(P/'C02706R_PAPER_CUTTER_ASSET_v001.blend'))
# Replace the four narrow bevelled grip ridges in memory with solid un-bevelled boxes.
# Previous native/GLBs remain unchanged on disk.
for old in [o for o in bpy.data.objects if o.name.startswith('Grip_ridge')]:
 name=old.name;loc=old.location.copy();rot=old.rotation_euler.copy();mat=old.data.materials[0];bpy.data.objects.remove(old,do_unlink=True)
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=(.046,.047,.004);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.rotation_euler=rot
 for c in list(o.users_collection):c.objects.unlink(o)
 bpy.data.collections['RENDER_C02706R'].objects.link(o);o.data.materials.append(mat)
for kind,coll in [('RENDER','RENDER_C02706R'),('COL','COLLISION_PROXY')]:
 bpy.ops.object.select_all(action='DESELECT')
 for o in bpy.data.collections[coll].objects:o.hide_set(False);o.select_set(True)
 bpy.ops.export_scene.gltf(filepath=str(P/f'C02706R_PAPER_CUTTER_{kind}_v002.glb'),export_format='GLB',use_selection=True,export_apply=True)
for o in bpy.data.collections['COLLISION_PROXY'].objects:o.hide_set(True)
bpy.ops.object.select_all(action='DESELECT');bpy.context.scene.render.filepath=str(P/'PREVIEW_PAPER_CUTTER_HERO_v097_v002.png');bpy.ops.wm.save_as_mainfile(filepath=str(P/'C02706R_PAPER_CUTTER_ASSET_v002.blend'),compress=True)
