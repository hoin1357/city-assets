import bpy,bmesh,math,pathlib
from mathutils import Vector
P=pathlib.Path('/workspace/v097_paper_cutter');bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);s=bpy.context.scene;s.unit_settings.system='METRIC';s.unit_settings.scale_length=1
R=bpy.data.collections.new('RENDER_C02706R');s.collection.children.link(R);C=bpy.data.collections.new('COLLISION_PROXY');s.collection.children.link(C)
def mat(name,color,metal=0,rough=.5):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;n=m.node_tree.nodes.get('Principled BSDF');n.inputs['Base Color'].default_value=(*color,1);n.inputs['Metallic'].default_value=metal;n.inputs['Roughness'].default_value=rough;return m
paint=mat('Sage enamel',(.22,.32,.26),.2,.45);deck=mat('Warm cutting board',(.53,.46,.30),0,.75);steel=mat('Brushed metal',(.43,.47,.45),.8,.32);dark=mat('Graphite rubber',(.022,.028,.026),0,.75);ink=mat('Grid ink',(.12,.16,.12),0,.8);paper=mat('Paper stack',(.77,.76,.66),0,.9);red=mat('Lever accent',(.38,.055,.035),.2,.5)
def move(o,name,m,coll=R):
 o.name=name
 for c in list(o.users_collection):c.objects.unlink(o)
 coll.objects.link(o)
 if m:o.data.materials.append(m)
 return o
def box(name,loc,size,m,bevel=.002,coll=R):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=move(bpy.context.object,name,m,coll);o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 if bevel:
  mod=o.modifiers.new('Edge rounding','BEVEL');mod.width=bevel;mod.segments=2;bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=mod.name)
 return o
def rod(name,a,b,r,m,n=24):
 a,b=Vector(a),Vector(b);bpy.ops.mesh.primitive_cylinder_add(vertices=n,radius=r,depth=(b-a).length,location=(a+b)/2);o=move(bpy.context.object,name,m);o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o
def beam(name,a,b,width,depth,m,coll=R):
 a,b=Vector(a),Vector(b);o=box(name,(a+b)/2,(width,depth,(b-a).length),m,bevel=0 if coll==C else .002,coll=coll);o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o
box('Base_housing',(0,0,.04),(.42,.54,.05),paint,bevel=.012)
box('Grid_deck',(0,-.005,.066),(.384,.49,.008),deck,bevel=.003)
for x in [-.165,.165]:
 for y in [-.215,.215]:rod('Foot'+str((x,y)),(x,y,0),(x,y,.02),.021,dark,20)
# Actual raised geometry for a 25 mm grid; display marks are not calibrated tools.
grid=[]
for i in range(15):grid.append(box(f'GridX{i}',(-.175+i*.025,-.005,.07035),(.0007,.45,.0004),ink,bevel=0))
for j in range(19):grid.append(box(f'GridY{j}',(0,-.23+j*.025,.07035),(.35,.0007,.0004),ink,bevel=0))
bpy.ops.object.select_all(action='DESELECT')
for o in grid:o.select_set(True)
bpy.context.view_layer.objects.active=grid[0];bpy.ops.object.join();grid[0].name='Grid_lines'
box('Back_registration_fence',(-.015,.242,.082),(.39,.018,.027),steel)
box('Left_registration_fence',(-.19,-.005,.08),(.012,.48,.023),steel)
for i in range(18):box(f'Ruler_tick{i}',(-.18+i*.02,.231,.096),(.0008,.006 if i%5 else .011,.0005),ink,bevel=0)
# A small stack keeps most of the grid visible.
box('Paper_stack',(-.08,-.085,.073),(.14,.19,.004),paper,bevel=.0005)
for z in [.072,.073,.074]:box('Paper_edge_'+str(z),(-.08,-.1803,z),(.137,.0004,.0002),ink,bevel=0)
# Clamp rail and its fixed supports.
for y in [-.205,.205]:
 box('Clamp_support'+str(y),(.163,y,.086),(.025,.028,.031),paint)
 rod('Clamp_screw'+str(y),(.163,y,.10),(.163,y,.113),.008,dark,16)
box('Clamp_bar',(.163,0,.101),(.024,.43,.015),steel,bevel=.004)
box('Fixed_cutting_strip',(.207,0,.068),(.014,.51,.012),steel,bevel=.001)
# Hinge at the rear; open 30-degree pose, static decorative blade/lever assembly.
box('Hinge_block',(.215,.242,.093),(.068,.055,.064),paint,bevel=.006)
rod('Hinge_pin',(.17,.242,.104),(.265,.242,.104),.014,steel,32)
rod('Hinge_cap',(.262,.242,.104),(.272,.242,.104),.022,dark,32)
a=Vector((.233,.242,.104));direction=Vector((0,-math.cos(math.radians(30)),math.sin(math.radians(30))));up=Vector((0,.5,math.cos(math.radians(30))))
b=a+direction*.575
beam('Lever_spine',a+up*.018,b+up*.018,.022,.032,paint)
beam('Blade_visual_strip',a,b,.006,.035,steel)
beam('Lever_accent',a+direction*.40+up*.036,a+direction*.52+up*.036,.023,.004,red)
g0=a+direction*.565+up*.018;g1=a+direction*.69+up*.018
beam('Handle_grip',g0,g1,.043,.044,dark)
for t in [.585,.61,.635,.66]:
 c=a+direction*t+up*.018;beam('Grip_ridge'+str(t),c-direction*.002,c+direction*.002,.046,.047,paint)
# Fasteners and resting stop.
for x in [-.18,.18]:
 for y in [-.235,.21]:rod('Deck_fastener'+str((x,y)),(x,y,.070),(x,y,.073),.0045,steel,12)
box('Front_rest_stop',(.225,-.24,.073),(.035,.04,.022),dark,bevel=.003)
for name,loc,size in [('Base',(0,0,.0365),(.42,.54,.073)),('BackFence',(-.015,.242,.084),(.39,.022,.032)),('Clamp',(.163,0,.096),(.03,.46,.039)),('Hinge',(.222,.242,.097),(.10,.06,.067))]:box('COL_'+name,loc,size,None,bevel=0,coll=C)
beam('COL_Lever',a,b+up*.015,.033,.066,None,C);beam('COL_Handle',g0,g1,.048,.05,None,C)
for o in list(R.objects)+list(C.objects):
 bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(o.data);bm.free()
for kind,coll in [('RENDER',R),('COL',C)]:
 bpy.ops.object.select_all(action='DESELECT')
 for o in coll.objects:o.select_set(True)
 bpy.ops.export_scene.gltf(filepath=str(P/f'C02706R_PAPER_CUTTER_{kind}_v001.glb'),export_format='GLB',use_selection=True,export_apply=True)
for o in C.objects:o.hide_render=True;o.hide_set(True);o.display_type='WIRE'
bpy.ops.object.select_all(action='DESELECT')
def aim(o,target):o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(.95,-1.25,.95));cam=bpy.context.object;aim(cam,(.02,-.03,.17));cam.data.type='ORTHO';cam.data.ortho_scale=.83;s.camera=cam;s.world.color=(.16,.16,.16)
for loc,power,size in [((.5,-.8,1.4),65,1.2),((-.8,-.2,.8),40,1),((0,.9,1.2),85,1)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.size=size;aim(o,(0,0,.15))
s.render.engine='CYCLES';s.cycles.samples=48;s.cycles.use_denoising=False;s.render.resolution_x=1200;s.render.resolution_y=1200;s.render.resolution_percentage=100;s.view_settings.view_transform='AgX';s.render.image_settings.file_format='PNG';s.render.filepath=str(P/'PREVIEW_PAPER_CUTTER_HERO_v097.png')
bpy.ops.wm.save_as_mainfile(filepath=str(P/'C02706R_PAPER_CUTTER_ASSET_v001.blend'),compress=True)
box('PREVIEW_ONLY_GROUND',(0,0,-.012),(200,200,.02),mat('Studio',(.12,.16,.18)),bevel=0);bpy.ops.render.render(write_still=True);print('BUILD_COMPLETE')
