import bpy,pathlib
P=pathlib.Path('/workspace/v097_paper_cutter');bpy.ops.wm.open_mainfile(filepath=str(P/'C02706R_PAPER_CUTTER_ASSET_v003.blend'));s=bpy.context.scene
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.002));o=bpy.context.object;o.name='PREVIEW_ONLY_GROUND';m=bpy.data.materials.new('Studio_preview');m.diffuse_color=(.12,.16,.18,1);o.data.materials.append(m);s.render.filepath=str(P/'PREVIEW_PAPER_CUTTER_HERO_v097_v003.png');bpy.ops.render.render(write_still=True)
