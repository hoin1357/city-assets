import pathlib,sys,hashlib,json,zipfile,subprocess
archive=pathlib.Path(sys.argv[1]);dest=pathlib.Path(sys.argv[2]);expected=sys.argv[3];sha=hashlib.sha256(archive.read_bytes()).hexdigest();assert sha==expected
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert all(not n.startswith('/') and '..' not in pathlib.Path(n).parts for n in z.namelist())
 z.extractall(dest)
m=json.loads((dest/'MANIFEST.json').read_text())
for r in m['files']:
 f=dest/r['path'];assert f.stat().st_size==r['bytes'];assert hashlib.sha256(f.read_bytes()).hexdigest()==r['sha256']
for f in dest.glob('*.blend'):
 r=subprocess.run(['blender','-b',str(f),'--python-expr',"import bpy; assert len(bpy.data.collections['RENDER_C02706R'].objects)==56; assert len(bpy.data.collections['COLLISION_PROXY'].objects)==6; print('REMOTE_REOPEN_OK')"],capture_output=True,text=True);assert r.returncode==0 and 'REMOTE_REOPEN_OK' in r.stdout,r.stdout+r.stderr
report={'bytes':archive.stat().st_size,'sha256':sha,'zip_crc':'PASS','manifest_files':len(m['files']),'manifest_sha_bytes':'PASS','blender_reopen':'PASS'};(dest/'REMOTE_VERIFY.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
