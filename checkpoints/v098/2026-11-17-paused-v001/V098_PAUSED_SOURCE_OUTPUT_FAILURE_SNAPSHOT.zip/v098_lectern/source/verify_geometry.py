import bpy,bmesh,math,pathlib,json,sys
from mathutils import Vector
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [];P=pathlib.Path(args[args.index('--asset-dir')+1]).resolve() if '--asset-dir' in args else pathlib.Path(__file__).resolve().parents[1]/'active';version=args[args.index('--version')+1] if '--version' in args else 'v001'
bpy.ops.wm.open_mainfile(filepath=str(P/f'C03901R_LECTERN_ASSET_{version}.blend'));R=list(bpy.data.collections['RENDER_C03901R'].objects);C=list(bpy.data.collections['COLLISION_PROXY'].objects);r={'method':'Fresh independent Blender process; no build imports; topology, volume, support contact, taper, inclination, GLB reimport','errors':[],'unity':'NOT_RUN','city_placement':'NOT_RUN','functionality':'NOT_IMPLEMENTED_NOT_VALIDATED'};pts=[];tri=0
for o in R+C:
 bm=bmesh.new();bm.from_mesh(o.data)
 if any(not e.is_manifold for e in bm.edges):r['errors'].append(o.name+':non_manifold')
 if any(f.calc_area()<=1e-12 for f in bm.faces):r['errors'].append(o.name+':degenerate')
 if bm.calc_volume(signed=True)<=0:r['errors'].append(o.name+':volume')
 assert all(math.isfinite(x) for v in bm.verts for x in v.co)
 if o in C:assert len(bm.verts)==8 and len(bm.faces)==6
 if o in R:pts.extend([o.matrix_world@v.co for v in o.data.vertices]);tri+=sum(len(f.verts)-2 for f in bm.faces)
 bm.free()
lo=[min(v[i] for v in pts) for i in range(3)];hi=[max(v[i] for v in pts) for i in range(3)];dims=[hi[i]-lo[i] for i in range(3)];assert abs(lo[2])<1e-5
board=bpy.data.objects['Inclined_reading_board'];angle=math.degrees(board.rotation_euler.x);assert abs(angle-12)<.001
wedge=bpy.data.objects['Top_support_wedge'];vs=[wedge.matrix_world@v.co for v in wedge.data.vertices];upper=sorted(vs,key=lambda v:v.z)[-4:];under=lambda y:board.location.z+math.tan(board.rotation_euler.x)*y-.02/math.cos(board.rotation_euler.x);gap=max(under(v.y)-v.z for v in upper)
if gap>.002:r['errors'].append('Top_support_gap')
column=bpy.data.objects['COL_TaperedColumn'];vs=[column.matrix_world@v.co for v in column.data.vertices];bottom=[v for v in vs if v.z<.2];top=[v for v in vs if v.z>1];bw=max(v.x for v in bottom)-min(v.x for v in bottom);tw=max(v.x for v in top)-min(v.x for v in top);assert tw<bw
assert len(C)==5;assert not [i for i in bpy.data.images if i.source=='FILE' and not i.packed_file]
r['native']={'render_meshes':len(R),'collision_convex_solids':len(C),'triangles':tri,'dimensions':dims,'bbox_min':lo,'bbox_max':hi,'board_angle':angle,'support_gap_m':gap,'collision_column_bottom_width':bw,'collision_column_top_width':tw,'external_dependencies':False};r['glb']={}
for kind,count in [('RENDER',len(R)),('COL',len(C))]:
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(P/f'C03901R_LECTERN_{kind}_{version}.glb'));meshes=[o for o in bpy.data.objects if o.type=='MESH'];assert len(meshes)==count
 for o in meshes:
  o.data.calc_loop_triangles();assert all(t.area>1e-12 for t in o.data.loop_triangles),o.name
 points=[o.matrix_world@v.co for o in meshes for v in o.data.vertices];d=[max(v[i] for v in points)-min(v[i] for v in points) for i in range(3)]
 if kind=='RENDER':assert max(abs(d[i]-dims[i]) for i in range(3))<1e-5
 r['glb'][kind]={'meshes':len(meshes),'dimensions':d,'reimport':'PASS','triangle_areas':'PASS'}
r['status']='PASS' if not r['errors'] else 'FAIL';(P/'INDEPENDENT_QA.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2));assert r['status']=='PASS'
