import bpy,bmesh,math,pathlib,sys
from mathutils import Vector,Matrix
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
P=pathlib.Path(args[args.index('--output')+1]).resolve() if '--output' in args else pathlib.Path(__file__).resolve().parents[1]/'active'
P.mkdir(parents=True,exist_ok=True)
if any(P.iterdir()):raise RuntimeError('Output directory must be empty; preserve previous outputs and select a new --output directory')
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);s=bpy.context.scene;s.unit_settings.system='METRIC';s.unit_settings.scale_length=1
R=bpy.data.collections.new('RENDER_C03901R');s.collection.children.link(R);C=bpy.data.collections.new('COLLISION_PROXY');s.collection.children.link(C)
def mat(name,color,metal=0,rough=.5):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;n=m.node_tree.nodes.get('Principled BSDF');n.inputs['Base Color'].default_value=(*color,1);n.inputs['Metallic'].default_value=metal;n.inputs['Roughness'].default_value=rough;return m
wood=mat('Walnut body',(.22,.10,.042),0,.48);edge=mat('Dark walnut edge',(.095,.043,.019),0,.45);inlay=mat('Warm wood inlay',(.34,.19,.082),0,.58);brass=mat('Brass screw heads',(.48,.32,.11),.75,.3);rubber=mat('Felt and rubber',(.022,.032,.029),0,.86);paper=mat('Blank speech pages',(.82,.79,.66),0,.85)
def move(o,name,m,coll=R):
 o.name=name
 for c in list(o.users_collection):c.objects.unlink(o)
 coll.objects.link(o)
 if m:o.data.materials.append(m)
 return o
def bevel(o,width):
 if width:
  mod=o.modifiers.new('Soft edges','BEVEL');mod.width=width;mod.segments=3;bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=mod.name)
def box(name,loc,size,m,radius=.003,coll=R):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=move(bpy.context.object,name,m,coll);o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);bevel(o,radius);return o
def tapered(name,bottom,top,z0,z1,m,radius=0,coll=R):
 vs=[(x*w/2,y*d/2,z) for w,d,z in [(bottom[0],bottom[1],z0),(top[0],top[1],z1)] for x,y in [(-1,-1),(1,-1),(1,1),(-1,1)]];faces=[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]
 mesh=bpy.data.meshes.new(name+'Mesh');mesh.from_pydata(vs,[],faces);mesh.update();o=bpy.data.objects.new(name,mesh);coll.objects.link(o)
 if m:o.data.materials.append(m)
 bevel(o,radius);return o
box('Foot_plinth',(0,0,.065),(.54,.46,.09),edge,.014)
box('Plinth_upper_step',(0,0,.121),(.44,.36,.035),wood,.006)
for x in [-.205,.205]:
 for y in [-.165,.165]:box('Rubber_pad'+str((x,y)),(x,y,.01),(.065,.065,.02),rubber,.004)
tapered('Tapered_wood_column',(.34,.28),(.215,.20),.135,1.085,wood,.006)
# Slim closed trapezoidal veneers emphasize the taper without textures.
for side in [-1,1]:
 for i in [-1,0,1]:
  xb=i*.085;xt=i*.052;yb=side*.1425;yt=side*.1025;w0=.055;w1=.034;z0=.20;z1=1.02;t=.003
  vs=[(x,y,z) for x,y,z in [(xb-w0/2,yb-side*t,z0),(xb+w0/2,yb-side*t,z0),(xt+w1/2,yt-side*t,z1),(xt-w1/2,yt-side*t,z1),(xb-w0/2,yb+side*t,z0),(xb+w0/2,yb+side*t,z0),(xt+w1/2,yt+side*t,z1),(xt-w1/2,yt+side*t,z1)]]
  mesh=bpy.data.meshes.new('VeneerMesh');mesh.from_pydata(vs,[],[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]);mesh.update();o=bpy.data.objects.new(f'Veneer_{side}_{i}',mesh);R.objects.link(o);o.data.materials.append(inlay if i==0 else edge)
box('Column_capital',(0,0,1.085),(.275,.25,.035),edge,.006)
# 12-degree inclined wooden reading board. Local -Y is the lower book-rest edge.
a=math.radians(12);rot=Matrix.Rotation(a,3,'X');origin=Vector((0,0,1.155))
def topbox(name,xyz,size,m,radius=.002,coll=R):
 o=box(name,origin+rot@Vector(xyz),size,m,radius,coll);o.rotation_euler.x=a;return o
# Closed wedge joins the level column cap to the tilted underside of the board.
y0,y1=-.12,.12;z0=1.095;zl=1.155+math.tan(a)*y0-.025;zh=1.155+math.tan(a)*y1-.025
vs=[(-.125,y0,z0),(.125,y0,z0),(.125,y1,z0),(-.125,y1,z0),(-.125,y0,zl),(.125,y0,zl),(.125,y1,zh),(-.125,y1,zh)];faces=[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)];mesh=bpy.data.meshes.new('Top_wedge_mesh');mesh.from_pydata(vs,[],faces);mesh.update();o=bpy.data.objects.new('Top_support_wedge',mesh);R.objects.link(o);o.data.materials.append(edge)
topbox('Inclined_reading_board',(0,0,0),(.70,.50,.04),wood,.008)
topbox('Reading_felt',(0,0,.0215),(.60,.40,.003),rubber,.001)
topbox('Lower_book_stop',(0,-.229,.039),(.65,.025,.044),edge,.004)
for x in [-.342,.342]:topbox('Side_edge'+str(x),(x,0,.007),(.016,.48,.04),edge,.003)
# Static blank pages, with non-legible edge hints only.
for i in range(3):topbox('Speech_page'+str(i),(-.045+i*.003,-.012+i*.003,.025+i*.0013),(.24,.30,.001),paper,0)
# Shallow pencil rest on the right side, not a separate functional assembly.
topbox('Pencil_tray_bottom',(.22,.025,.025),(.06,.21,.006),inlay,.001)
for x in [.19,.25]:topbox('Pencil_tray_side'+str(x),(x,.025,.032),(.007,.21,.015),edge,.001)
for y in [-.08,.13]:topbox('Pencil_tray_end'+str(y),(.22,y,.032),(.06,.007,.015),edge,.001)
# Visible fasteners on the lower stop, kept as decorative closed solids.
for x in [-.28,.28]:
 pos=origin+rot@Vector((x,-.229,.062));bpy.ops.mesh.primitive_cylinder_add(vertices=16,radius=.004,depth=.0015,location=pos);o=move(bpy.context.object,'Stop_fastener'+str(x),brass);o.rotation_euler.x=a
box('COL_Base',(0,0,.069),(.54,.46,.138),None,0,C)
tapered('COL_TaperedColumn',(.35,.29),(.225,.21),.135,1.105,None,0,C)
box('COL_Top_support',(0,0,1.103),(.28,.255,.065),None,0,C)
topbox('COL_Reading_board',(0,0,.005),(.70,.50,.055),None,0,C)
topbox('COL_Book_stop',(0,-.229,.039),(.65,.03,.048),None,0,C)
for o in list(R.objects)+list(C.objects):
 bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(o.data);bm.free()
for kind,coll in [('RENDER',R),('COL',C)]:
 bpy.ops.object.select_all(action='DESELECT')
 for o in coll.objects:o.select_set(True)
 bpy.ops.export_scene.gltf(filepath=str(P/f'C03901R_LECTERN_{kind}_v001.glb'),export_format='GLB',use_selection=True,export_apply=True)
for o in C.objects:o.hide_render=True;o.hide_set(True);o.display_type='WIRE'
bpy.ops.object.select_all(action='DESELECT')
def aim(o,target):o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(2.5,-3.8,2.6));cam=bpy.context.object;aim(cam,(0,0,.64));cam.data.type='ORTHO';cam.data.ortho_scale=1.65;s.camera=cam;s.world.color=(.16,.16,.16)
for loc,power,size in [((1,-3,4),450,3),((-3,-1,2.5),300,3),((0,3,3),650,3)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.size=size;aim(o,(0,0,.6))
s.render.engine='CYCLES';s.cycles.samples=48;s.cycles.use_denoising=False;s.render.resolution_x=1200;s.render.resolution_y=1200;s.render.resolution_percentage=100;s.view_settings.view_transform='AgX';s.render.image_settings.file_format='PNG';s.render.filepath=str(P/'PREVIEW_LECTERN_HERO_v098.png')
bpy.ops.wm.save_as_mainfile(filepath=str(P/'C03901R_LECTERN_ASSET_v001.blend'),compress=True)
box('PREVIEW_ONLY_GROUND',(0,0,-.012),(200,200,.02),mat('Studio',(.12,.16,.18)),0);bpy.ops.render.render(write_still=True);print('BUILD_COMPLETE')
