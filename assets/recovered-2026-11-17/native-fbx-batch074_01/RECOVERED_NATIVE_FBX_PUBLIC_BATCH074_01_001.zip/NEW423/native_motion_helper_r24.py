"""NEW423 original generic attic ladder: edit last line and Run Script.
0 deployed,1 lower folded,2 both lower sections folded,3 hatch closed/unlatched,
4 latched. Intermediate values supported in each sequential interval.
No Actions, simulation, load certification or arbitrary-angle guarantees.
"""
import bpy,math
from mathutils import Vector

def set_operation(operation):
 p=float(operation)
 if not math.isfinite(p) or not 0<=p<=4:raise ValueError('Operation must be finite and between0and4')
 O=bpy.data.objects
 hatch=O['Hatch pivot'];hatch.rotation_euler.x=-math.radians(65)*(1-min(max(p-2,0),1))
 O['Middle folding hinge'].rotation_euler.x=math.pi*min(max(p-1,0),1)
 O['Lower folding hinge'].rotation_euler.x=math.pi*min(p,1)
 O['Latch tongue'].location.y=1.262+.035*min(max(p-3,0),1)
 bpy.context.view_layer.update();base=O['Ceiling frame datum']
 def rod(name,a,b):
  ob=O[name];a,b=Vector(a),Vector(b);v=b-a
  for vv in ob.data.vertices:vv.co.z=(1 if vv.co.z>=0 else -1)*v.length/2
  ob.location=(a+b)/2;ob.rotation_mode='QUATERNION';ob.rotation_quaternion=v.to_track_quat('Z','Y');ob.data.update()
 for side in [-1,1]:
  x=side*.259;P=Vector((x,1.05,.10));Q=base.matrix_world.inverted()@(hatch.matrix_world@Vector((x,.75,.04)));delta=Q-P;d=delta.length;u=delta/d;t=(.67**2-.40**2+d*d)/(2*d);perp=Vector((0,-u.z,u.y));K=P+u*t-perp*math.sqrt(.67**2-t*t)
  for name,a,b,lane in [('Upper support arm',P,K,.249),('Lower support arm',K,Q,.259)]:
   aa=a.copy();bb=b.copy();aa.x=bb.x=side*lane;rod(name+str(side),aa,bb)
  for name,pt in [('Frame arm seat',P),('Knee pin',K),('Hatch arm seat',Q)]:rod(name+str(side),(side*(.244 if name=='Knee pin' else .230),pt.y,pt.z),(side*(.264 if name=='Knee pin' else .298 if name=='Frame arm seat' else .290),pt.y,pt.z))
  S=Vector((side*.273,1.08,.20));T=P+(K-P)*.7;T.x=side*.273
  rod('Spring moving anchor'+str(side),(side*.246,T.y,T.z),(side*.280,T.y,T.z));rod('Spring extension core'+str(side),S,T)
  coil=O['Tension coil'+str(side)];N=len(coil.data.vertices)//6-1;v=T-S;axis=v.normalized();e=Vector((1,0,0));f=axis.cross(e);points=[]
  for j in range(N+1):
   q=j/N;r=.0055*min(1,q*12,(1-q)*12);points.append(S+v*q+r*(e*math.cos(q*math.tau*12)+f*math.sin(q*math.tau*12)))
  for j,pt in enumerate(points):
   tangent=(points[min(j+1,N)]-points[max(j-1,0)]).normalized();aa=tangent.cross(Vector((1,0,0))).normalized();bb=tangent.cross(aa)
   for k in range(6):coil.data.vertices[j*6+k].co=pt+.0015*(aa*math.cos(k*math.tau/6)+bb*math.sin(k*math.tau/6))
  coil.data.update()
 hatch['operation']=p;bpy.context.view_layer.update()
 return p

set_operation(0.0)
